// Game Types for Fisch Dashboard

export type Rarity = 
  | 'Trash' 
  | 'Common' 
  | 'Uncommon' 
  | 'Unusual' 
  | 'Rare' 
  | 'Legendary' 
  | 'Mythical' 
  | 'Exotic' 
  | 'Secret' 
  | 'Relic' 
  | 'Fragment' 
  | 'Extinct' 
  | 'Limited' 
  | 'Apex' 
  | 'Cataclysmic' 
  | 'Special';

export interface Fish {
  id: string;
  name: string;
  rarity: Rarity;
  baseValue: number;
  minWeight: number;
  maxWeight: number;
  xp: number;
  location: string[];
  weather?: string[];
  time?: string[];
  bait?: string[];
  description: string;
  unlocked: boolean;
  caughtCount: number;
  bestWeight: number;
  mutations: Mutation[];
}

export interface Mutation {
  type: string;
  valueMultiplier: number;
  chance: number;
}

export interface Rod {
  id: string;
  name: string;
  description: string;
  luck: number;
  lureSpeed: number;
  resilience: number;
  control: number;
  cost: number;
  levelRequired: number;
  owned: boolean;
  equipped: boolean;
  image?: string;
  passive?: string;
}

export interface Bait {
  id: string;
  name: string;
  description: string;
  luck: number;
  lureSpeed: number;
  resilience: number;
  preferredLuck: number;
  cost: number;
  count: number;
}

export interface PlayerStats {
  level: number;
  xp: number;
  maxXp: number;
  money: number;
  totalFishCaught: number;
  reelsSnapped: number;
  catchStreak: number;
  bestStreak: number;
  fishDiscovered: number;
  totalFishTypes: number;
  title: string;
}

export interface Location {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
  levelRequired: number;
  fishTypes: string[];
  weather: string;
}

export type GamePhase = 'idle' | 'casting' | 'shaking' | 'reeling' | 'caught' | 'escaped';

export interface ActiveFish {
  fish: Fish;
  weight: number;
  mutation?: Mutation;
  resilience: number;
  progressSpeed: number;
}

export interface Enchantment {
  id: string;
  name: string;
  description: string;
  effect: string;
  luckBonus?: number;
  lureSpeedBonus?: number;
  resilienceBonus?: number;
  controlBonus?: number;
}
