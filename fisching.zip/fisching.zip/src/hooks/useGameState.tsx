import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import type { Fish, Rod, Bait, PlayerStats, GamePhase, ActiveFish, Location } from '@/types/game';
import { fishDatabase } from '@/data/fishDatabase';
import { rodDatabase } from '@/data/rodDatabase';
import { baitDatabase } from '@/data/baitDatabase';

interface GameState {
  // Player Data
  stats: PlayerStats;
  inventory: {
    fish: Fish[];
    rods: Rod[];
    bait: Bait[];
  };
  locations: Location[];
  
  // Fishing State
  gamePhase: GamePhase;
  activeFish: ActiveFish | null;
  equippedRod: Rod | null;
  equippedBait: Bait | null;
  currentLocation: Location | null;
  
  // Actions
  castLine: () => void;
  shakeLine: () => void;
  startReeling: () => void;
  updateReelProgress: (progress: number) => void;
  catchFish: () => void;
  loseFish: () => void;
  equipRod: (rodId: string) => void;
  equipBait: (baitId: string) => void;
  buyRod: (rodId: string) => void;
  buyBait: (baitId: string, amount: number) => void;
  sellFish: (fishId: string) => void;
  sellAllFish: () => void;
  addXp: (amount: number) => void;
  travelToLocation: (locationId: string) => void;
}

const initialStats: PlayerStats = {
  level: 1,
  xp: 0,
  maxXp: 100,
  money: 500,
  totalFishCaught: 0,
  reelsSnapped: 0,
  catchStreak: 0,
  bestStreak: 0,
  fishDiscovered: 0,
  totalFishTypes: fishDatabase.length,
  title: 'Rookie',
};

const initialLocations: Location[] = [
  {
    id: 'moosewood',
    name: 'Moosewood',
    description: 'A peaceful starting area with common fish.',
    unlocked: true,
    levelRequired: 1,
    fishTypes: ['common_anchovy', 'common_sardine', 'common_herring', 'common_mackerel', 'common_cod', 'uncommon_trout', 'uncommon_bass', 'unusual_pike', 'unusual_carp'],
    weather: 'Clear',
  },
  {
    id: 'roslit_bay',
    name: 'Roslit Bay',
    description: 'A beautiful bay with diverse fish species.',
    unlocked: true,
    levelRequired: 5,
    fishTypes: ['common_anchovy', 'common_sardine', 'common_mackerel', 'uncommon_trout', 'uncommon_bass', 'uncommon_perch', 'uncommon_wrasse', 'unusual_snapper', 'rare_mahi', 'rare_stingray', 'legendary_sunfish'],
    weather: 'Clear',
  },
  {
    id: 'forsaken_shores',
    name: 'Forsaken Shores',
    description: 'Dangerous waters with large predators.',
    unlocked: false,
    levelRequired: 15,
    fishTypes: ['common_cod', 'unusual_catfish', 'rare_tuna', 'rare_swordfish', 'rare_marlin', 'legendary_shark'],
    weather: 'Stormy',
  },
  {
    id: 'the_depths',
    name: 'The Depths',
    description: 'Deep ocean abyss with mysterious creatures.',
    unlocked: false,
    levelRequired: 30,
    fishTypes: ['legendary_angler', 'legendary_oarfish', 'mythical_kraken', 'mythical_colossal'],
    weather: 'Dark',
  },
  {
    id: 'ancient_isle',
    name: 'Ancient Isle',
    description: 'Home to prehistoric fish.',
    unlocked: false,
    levelRequired: 50,
    fishTypes: ['exotic_coelacanth', 'exotic_megalodon'],
    weather: 'Foggy',
  },
];

const GameStateContext = createContext<GameState | undefined>(undefined);

export function GameStateProvider({ children }: { children: React.ReactNode }) {
  // Player State
  const [stats, setStats] = useState<PlayerStats>(initialStats);
  const [inventory, setInventory] = useState({
    fish: [] as Fish[],
    rods: rodDatabase,
    bait: baitDatabase,
  });
  const [locations] = useState<Location[]>(initialLocations);
  
  // Fishing State
  const [gamePhase, setGamePhase] = useState<GamePhase>('idle');
  const [activeFish, setActiveFish] = useState<ActiveFish | null>(null);
  const [currentLocation, setCurrentLocation] = useState<Location | null>(initialLocations[0]);
  
  // Derived State
  const equippedRod = useMemo(() => 
    inventory.rods.find(r => r.equipped) || inventory.rods[0],
    [inventory.rods]
  );
  
  const equippedBait = useMemo(() => 
    inventory.bait.find(b => b.count > 0) || null,
    [inventory.bait]
  );

  // Helper: Calculate XP needed for next level
  const getXpForLevel = (level: number): number => {
    if (level <= 1000) {
      return 100 + (level - 1) * 190;
    }
    return 100 + 999 * 190 + (level - 1000) * 380;
  };

  // Helper: Get title based on level
  const getTitleForLevel = (level: number): string => {
    if (level >= 200) return 'Stormcaller';
    if (level >= 100) return 'Eternal Voyager';
    if (level >= 90) return 'Sea Sovereign';
    if (level >= 80) return 'Mythical Seeker';
    if (level >= 70) return 'Grand Pioneer';
    if (level >= 60) return 'Legendary Explorer';
    if (level >= 50) return 'Ocean Hero';
    if (level >= 40) return 'Famous Voyager';
    if (level >= 33) return 'Renowned Navigator';
    if (level >= 25) return 'Sea Scout';
    if (level >= 12) return 'Trusted Explorer';
    if (level >= 7) return 'Novice Explorer';
    return 'Rookie';
  };

  // Action: Cast Line
  const castLine = useCallback(() => {
    if (gamePhase !== 'idle') return;
    setGamePhase('casting');
    
    // Simulate casting animation time
    setTimeout(() => {
      setGamePhase('shaking');
    }, 1500);
  }, [gamePhase]);

  // Action: Shake Line
  const shakeLine = useCallback(() => {
    if (gamePhase !== 'shaking') return;
    
    // Calculate lure speed with rod and bait bonuses
    const lureSpeed = (equippedRod?.lureSpeed || 0) + (equippedBait?.lureSpeed || 0);
    const shakeTime = Math.max(500, 2000 - lureSpeed * 30);
    
    setTimeout(() => {
      // Determine if fish bites
      const biteChance = 0.8 + (equippedBait?.luck || 0) / 200;
      if (Math.random() < biteChance) {
        generateFish();
        setGamePhase('reeling');
      } else {
        setGamePhase('idle');
      }
    }, shakeTime);
  }, [gamePhase, equippedRod, equippedBait]);

  // Helper: Generate a fish based on luck and location
  const generateFish = useCallback(() => {
    if (!currentLocation) return;
    
    const totalLuck = (equippedRod?.luck || 0) + (equippedBait?.luck || 0) + (equippedBait?.preferredLuck || 0);
    
    // Filter fish available in current location
    const availableFish = fishDatabase.filter(f => 
      currentLocation.fishTypes.includes(f.id) || f.location.includes('any')
    );
    
    // Weight fish by rarity and luck
    const weightedFish = availableFish.map(fish => {
      let weight = getRarityWeight(fish.rarity);
      // Luck increases chance for rarer fish
      weight *= (1 + totalLuck / 100);
      return { fish, weight };
    });
    
    // Select fish based on weights
    const totalWeight = weightedFish.reduce((sum, fw) => sum + fw.weight, 0);
    let random = Math.random() * totalWeight;
    
    let selectedFish = availableFish[0];
    for (const fw of weightedFish) {
      random -= fw.weight;
      if (random <= 0) {
        selectedFish = fw.fish;
        break;
      }
    }
    
    // Generate weight
    const weight = selectedFish.minWeight + Math.random() * (selectedFish.maxWeight - selectedFish.minWeight);
    
    // Calculate resilience based on rarity
    const resilience = getRarityResilience(selectedFish.rarity);
    
    setActiveFish({
      fish: selectedFish,
      weight: parseFloat(weight.toFixed(2)),
      resilience,
      progressSpeed: 12 + (equippedRod?.resilience || 0) / 10,
    });
  }, [currentLocation, equippedRod, equippedBait]);

  // Helper: Get rarity weight for fish selection
  const getRarityWeight = (rarity: string): number => {
    const weights: Record<string, number> = {
      'Trash': 30,
      'Common': 50,
      'Uncommon': 25,
      'Unusual': 15,
      'Rare': 8,
      'Legendary': 3,
      'Mythical': 1,
      'Exotic': 0.3,
      'Secret': 0.03,
    };
    return weights[rarity] || 1;
  };

  // Helper: Get resilience based on rarity
  const getRarityResilience = (rarity: string): number => {
    const resilience: Record<string, number> = {
      'Trash': 10,
      'Common': 20,
      'Uncommon': 35,
      'Unusual': 50,
      'Rare': 70,
      'Legendary': 85,
      'Mythical': 95,
      'Exotic': 100,
      'Secret': 120,
    };
    return resilience[rarity] || 50;
  };

  // Action: Start Reeling
  const startReeling = useCallback(() => {
    setGamePhase('reeling');
  }, []);

  // Action: Update Reel Progress
  const updateReelProgress = useCallback((progress: number) => {
    if (progress >= 100) {
      catchFish();
    } else if (progress <= 0) {
      loseFish();
    }
  }, []);

  // Action: Catch Fish
  const catchFish = useCallback(() => {
    if (!activeFish) return;
    
    const caughtFish = { ...activeFish.fish };
    caughtFish.caughtCount = 1;
    caughtFish.bestWeight = activeFish.weight;
    caughtFish.unlocked = true;
    
    // Calculate value based on weight and mutation
    const baseValue = caughtFish.baseValue;
    const weightMultiplier = activeFish.weight / caughtFish.minWeight;
    const finalValue = Math.floor(baseValue * weightMultiplier);
    
    // Calculate XP
    const xpGained = Math.floor(caughtFish.xp * (1 + (equippedRod?.control || 0) / 100));
    
    setInventory(prev => ({
      ...prev,
      fish: [...prev.fish, caughtFish],
    }));
    
    setStats(prev => ({
      ...prev,
      money: prev.money + finalValue,
      totalFishCaught: prev.totalFishCaught + 1,
      catchStreak: prev.catchStreak + 1,
      bestStreak: Math.max(prev.bestStreak, prev.catchStreak + 1),
    }));
    
    addXp(xpGained);
    
    setGamePhase('caught');
    setTimeout(() => {
      setGamePhase('idle');
      setActiveFish(null);
    }, 2000);
  }, [activeFish, equippedRod]);

  // Action: Lose Fish
  const loseFish = useCallback(() => {
    setStats(prev => ({
      ...prev,
      reelsSnapped: prev.reelsSnapped + 1,
      catchStreak: 0,
    }));
    
    setGamePhase('escaped');
    setTimeout(() => {
      setGamePhase('idle');
      setActiveFish(null);
    }, 1500);
  }, []);

  // Action: Equip Rod
  const equipRod = useCallback((rodId: string) => {
    setInventory(prev => ({
      ...prev,
      rods: prev.rods.map(rod => ({
        ...rod,
        equipped: rod.id === rodId,
      })),
    }));
  }, []);

  // Action: Equip Bait
  const equipBait = useCallback((_baitId: string) => {
    // Bait is consumed when used, so we just track which is selected
    // TODO: Implement bait selection logic
  }, []);

  // Action: Buy Rod
  const buyRod = useCallback((rodId: string) => {
    const rod = inventory.rods.find(r => r.id === rodId);
    if (!rod || rod.owned || stats.money < rod.cost) return;
    
    setStats(prev => ({ ...prev, money: prev.money - rod.cost }));
    setInventory(prev => ({
      ...prev,
      rods: prev.rods.map(r => 
        r.id === rodId ? { ...r, owned: true } : r
      ),
    }));
  }, [inventory.rods, stats.money]);

  // Action: Buy Bait
  const buyBait = useCallback((baitId: string, amount: number) => {
    const bait = inventory.bait.find(b => b.id === baitId);
    if (!bait) return;
    
    const totalCost = bait.cost * amount;
    if (stats.money < totalCost) return;
    
    setStats(prev => ({ ...prev, money: prev.money - totalCost }));
    setInventory(prev => ({
      ...prev,
      bait: prev.bait.map(b => 
        b.id === baitId ? { ...b, count: b.count + amount } : b
      ),
    }));
  }, [inventory.bait, stats.money]);

  // Action: Sell Fish
  const sellFish = useCallback((fishId: string) => {
    const fishIndex = inventory.fish.findIndex(f => f.id === fishId);
    if (fishIndex === -1) return;
    
    const fish = inventory.fish[fishIndex];
    const value = fish.baseValue;
    
    setStats(prev => ({ ...prev, money: prev.money + value }));
    setInventory(prev => ({
      ...prev,
      fish: prev.fish.filter((_, i) => i !== fishIndex),
    }));
  }, [inventory.fish]);

  // Action: Sell All Fish
  const sellAllFish = useCallback(() => {
    const totalValue = inventory.fish.reduce((sum, fish) => sum + fish.baseValue, 0);
    
    setStats(prev => ({ ...prev, money: prev.money + totalValue }));
    setInventory(prev => ({ ...prev, fish: [] }));
  }, [inventory.fish]);

  // Action: Add XP
  const addXp = useCallback((amount: number) => {
    setStats(prev => {
      let newXp = prev.xp + amount;
      let newLevel = prev.level;
      let newMaxXp = prev.maxXp;
      
      while (newXp >= newMaxXp) {
        newXp -= newMaxXp;
        newLevel++;
        newMaxXp = getXpForLevel(newLevel);
      }
      
      return {
        ...prev,
        xp: newXp,
        maxXp: newMaxXp,
        level: newLevel,
        title: getTitleForLevel(newLevel),
      };
    });
  }, []);

  // Action: Travel to Location
  const travelToLocation = useCallback((locationId: string) => {
    const location = locations.find(l => l.id === locationId);
    if (!location || !location.unlocked || stats.level < location.levelRequired) return;
    
    setCurrentLocation(location);
  }, [locations, stats.level]);

  const value = useMemo(() => ({
    stats,
    inventory,
    locations,
    gamePhase,
    activeFish,
    equippedRod,
    equippedBait,
    currentLocation,
    castLine,
    shakeLine,
    startReeling,
    updateReelProgress,
    catchFish,
    loseFish,
    equipRod,
    equipBait,
    buyRod,
    buyBait,
    sellFish,
    sellAllFish,
    addXp,
    travelToLocation,
  }), [
    stats, inventory, locations, gamePhase, activeFish,
    equippedRod, equippedBait, currentLocation,
    castLine, shakeLine, startReeling, updateReelProgress,
    catchFish, loseFish, equipRod, equipBait,
    buyRod, buyBait, sellFish, sellAllFish, addXp, travelToLocation,
  ]);

  return (
    <GameStateContext.Provider value={value}>
      {children}
    </GameStateContext.Provider>
  );
}

export function useGameState() {
  const context = useContext(GameStateContext);
  if (context === undefined) {
    throw new Error('useGameState must be used within a GameStateProvider');
  }
  return context;
}
