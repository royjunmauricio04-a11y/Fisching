import { useState } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Fish, Backpack, Check, X, Worm } from 'lucide-react';
import { getRarityColor } from '@/data/fishDatabase';
import type { Rod, Bait, Fish as FishType } from '@/types/game';

// Rod Card Component
function RodCard({ rod, onEquip }: { rod: Rod; onEquip: () => void }) {
  return (
    <div 
      className={`
        relative p-4 rounded-xl border-2 transition-all duration-300
        ${rod.equipped 
          ? 'bg-[#52b7d3]/20 border-[#52b7d3] shadow-[0_0_20px_rgba(82,183,211,0.3)]' 
          : rod.owned
            ? 'bg-[#0f3b4f]/60 border-[#52b7d3]/30 hover:border-[#52b7d3]/60'
            : 'bg-[#061f2f]/60 border-white/10 opacity-60'
        }
      `}
    >
      {rod.equipped && (
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-[#52b7d3] rounded-full flex items-center justify-center">
          <Check className="w-4 h-4 text-white" />
        </div>
      )}
      
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#52b7d3]/20 to-[#1da2c0]/20 flex items-center justify-center text-3xl">
          🎣
        </div>
        
        <div className="flex-1">
          <h3 className="font-bold text-white">{rod.name}</h3>
          <p className="text-white/60 text-sm">{rod.description}</p>
          
          {rod.owned && (
            <div className="grid grid-cols-2 gap-2 mt-3">
              <div className="text-xs">
                <span className="text-white/40">Luck:</span>
                <span className="text-[#f7d07a] ml-1">+{rod.luck}%</span>
              </div>
              <div className="text-xs">
                <span className="text-white/40">Speed:</span>
                <span className="text-[#52b7d3] ml-1">+{rod.lureSpeed}%</span>
              </div>
              <div className="text-xs">
                <span className="text-white/40">Resilience:</span>
                <span className="text-green-400 ml-1">+{rod.resilience}%</span>
              </div>
              <div className="text-xs">
                <span className="text-white/40">Control:</span>
                <span className="text-purple-400 ml-1">+{rod.control}%</span>
              </div>
            </div>
          )}
          
          {rod.passive && (
            <p className="text-xs text-[#f7d07a] mt-2 italic">{rod.passive}</p>
          )}
        </div>
      </div>
      
      {rod.owned ? (
        !rod.equipped && (
          <Button 
            onClick={onEquip}
            className="w-full mt-3 bg-[#52b7d3]/20 hover:bg-[#52b7d3]/40 text-[#52b7d3] border border-[#52b7d3]/50"
          >
            Equip
          </Button>
        )
      ) : (
        <div className="mt-3 text-center">
          <p className="text-white/40 text-sm">Level {rod.levelRequired} required</p>
          <p className="text-[#f7d07a] font-bold">{rod.cost.toLocaleString()} C$</p>
        </div>
      )}
    </div>
  );
}

// Bait Card Component
function BaitCard({ bait }: { bait: Bait }) {
  return (
    <div className="p-4 rounded-xl bg-[#0f3b4f]/60 border border-[#52b7d3]/30">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#f7d07a]/20 to-[#d4a84b]/20 flex items-center justify-center text-2xl">
          🪱
        </div>
        
        <div className="flex-1">
          <h3 className="font-bold text-white">{bait.name}</h3>
          <p className="text-white/60 text-sm">{bait.description}</p>
          
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="text-xs">
              <span className="text-white/40">Luck:</span>
              <span className="text-[#f7d07a] ml-1">+{bait.luck}%</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Speed:</span>
              <span className="text-[#52b7d3] ml-1">+{bait.lureSpeed}%</span>
            </div>
            {bait.preferredLuck > 0 && (
              <div className="text-xs col-span-2">
                <span className="text-white/40">Preferred:</span>
                <span className="text-green-400 ml-1">+{bait.preferredLuck}%</span>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="mt-3 flex items-center justify-between">
        <Badge variant="secondary" className="bg-[#52b7d3]/20 text-[#52b7d3]">
          {bait.count} owned
        </Badge>
        <p className="text-[#f7d07a] text-sm">{bait.cost} C$ each</p>
      </div>
    </div>
  );
}

// Fish Card Component
function FishCard({ fish }: { fish: FishType }) {
  const rarityColor = getRarityColor(fish.rarity);
  
  return (
    <div 
      className="p-4 rounded-xl bg-[#0f3b4f]/60 border-2 transition-all duration-300 hover:scale-[1.02]"
      style={{ borderColor: `${rarityColor}40` }}
    >
      <div className="flex items-start gap-4">
        <div 
          className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl"
          style={{ backgroundColor: `${rarityColor}20` }}
        >
          🐟
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-white">{fish.name}</h3>
            <Badge 
              className="text-xs"
              style={{ 
                backgroundColor: `${rarityColor}30`,
                color: rarityColor,
                borderColor: rarityColor
              }}
            >
              {fish.rarity}
            </Badge>
          </div>
          
          <p className="text-white/60 text-sm mt-1">{fish.description}</p>
          
          <div className="grid grid-cols-3 gap-2 mt-3">
            <div className="text-xs">
              <span className="text-white/40">Weight:</span>
              <span className="text-white ml-1">{fish.minWeight}-{fish.maxWeight}kg</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Value:</span>
              <span className="text-[#f7d07a] ml-1">{fish.baseValue} C$</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">XP:</span>
              <span className="text-green-400 ml-1">{fish.xp}</span>
            </div>
          </div>
          
          {fish.caughtCount > 0 && (
            <div className="mt-2 text-xs text-white/40">
              Caught {fish.caughtCount} times • Best: {fish.bestWeight}kg
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Main Inventory Component
export function Inventory() {
  const { inventory, equipRod, sellFish, sellAllFish } = useGameState();
  const [activeTab, setActiveTab] = useState('rods');

  const ownedFish = inventory.fish;
  const totalFishValue = ownedFish.reduce((sum, fish) => sum + fish.baseValue, 0);

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Rowdies, sans-serif' }}>
              Inventory
            </h1>
            <p className="text-white/60">Manage your equipment and catches</p>
          </div>
          
          {ownedFish.length > 0 && (
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-white/60 text-sm">Total Value</p>
                <p className="text-[#f7d07a] font-bold text-xl">{totalFishValue.toLocaleString()} C$</p>
              </div>
              <Button 
                onClick={sellAllFish}
                className="bg-gradient-to-r from-[#f7d07a] to-[#d4a84b] text-[#061f2f] font-bold hover:opacity-90"
              >
                Sell All
              </Button>
            </div>
          )}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-[#0f3b4f]/60 p-1 rounded-xl">
            <TabsTrigger 
              value="rods" 
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Backpack className="w-4 h-4 mr-2" />
              Rods ({inventory.rods.filter(r => r.owned).length})
            </TabsTrigger>
            <TabsTrigger 
              value="bait"
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Worm className="w-4 h-4 mr-2" />
              Bait ({inventory.bait.reduce((sum, b) => sum + b.count, 0)})
            </TabsTrigger>
            <TabsTrigger 
              value="fish"
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Fish className="w-4 h-4 mr-2" />
              Fish ({ownedFish.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rods" className="space-y-4">
            <ScrollArea className="h-[600px]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {inventory.rods.map(rod => (
                  <RodCard 
                    key={rod.id} 
                    rod={rod} 
                    onEquip={() => equipRod(rod.id)}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="bait" className="space-y-4">
            <ScrollArea className="h-[600px]">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {inventory.bait.map(bait => (
                  <BaitCard key={bait.id} bait={bait} />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="fish" className="space-y-4">
            {ownedFish.length === 0 ? (
              <div className="text-center py-20">
                <Fish className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white/40">No fish yet</h3>
                <p className="text-white/30">Go fishing to catch some!</p>
              </div>
            ) : (
              <ScrollArea className="h-[600px]">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ownedFish.map((fish, index) => (
                    <div key={`${fish.id}-${index}`} className="relative group">
                      <FishCard fish={fish} />
                      <Button
                        onClick={() => sellFish(fish.id)}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-red-500/80 hover:bg-red-500 text-white"
                        size="sm"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
