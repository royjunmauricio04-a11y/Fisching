import { useState, useMemo } from 'react';
import { fishDatabase, getRarityColor } from '@/data/fishDatabase';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Filter, Fish, Lock, Check } from 'lucide-react';
import type { Rarity } from '@/types/game';

const rarities: Rarity[] = [
  'Trash', 'Common', 'Uncommon', 'Unusual', 'Rare', 
  'Legendary', 'Mythical', 'Exotic', 'Secret'
];

export function Bestiary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRarity, setSelectedRarity] = useState<Rarity | 'all'>('all');
  const [, setSelectedFish] = useState<string | null>(null);

  // Simulate discovered fish (in real app, this would come from game state)
  const discoveredFish = useMemo(() => {
    return new Set(['trash_boot', 'common_anchovy', 'common_sardine', 'uncommon_trout']);
  }, []);

  const filteredFish = useMemo(() => {
    return fishDatabase.filter(fish => {
      const matchesSearch = fish.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRarity = selectedRarity === 'all' || fish.rarity === selectedRarity;
      return matchesSearch && matchesRarity;
    });
  }, [searchQuery, selectedRarity]);

  const discoveredCount = discoveredFish.size;
  const totalCount = fishDatabase.length;
  const completionPercentage = (discoveredCount / totalCount) * 100;

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Rowdies, sans-serif' }}>
            Bestiary
          </h1>
          <p className="text-white/60">Discover and catalog every fish in the ocean</p>
        </div>

        {/* Progress Card */}
        <div className="bg-gradient-to-br from-[#0f3b4f] to-[#061f2f] rounded-2xl p-6 border border-[#52b7d3]/30 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#52b7d3]/30 to-[#1da2c0]/30 flex items-center justify-center">
                <Fish className="w-8 h-8 text-[#52b7d3]" />
              </div>
              <div>
                <p className="text-white/60 text-sm">Collection Progress</p>
                <p className="text-3xl font-bold text-white">
                  {discoveredCount} <span className="text-white/40">/ {totalCount}</span>
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-4xl font-bold text-[#f7d07a]">{completionPercentage.toFixed(1)}%</p>
              <p className="text-white/40 text-sm">Complete</p>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="h-4 bg-[#061f2f] rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-[#52b7d3] via-[#7dd3ed] to-[#f7d07a] transition-all duration-1000"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          
          {/* Rarity Breakdown */}
          <div className="grid grid-cols-3 md:grid-cols-9 gap-2 mt-6">
            {rarities.map(rarity => {
              const count = fishDatabase.filter(f => f.rarity === rarity).length;
              const discovered = fishDatabase.filter(f => f.rarity === rarity && discoveredFish.has(f.id)).length;
              const color = getRarityColor(rarity);
              
              return (
                <div 
                  key={rarity}
                  className="text-center p-2 rounded-lg bg-[#061f2f]/50"
                >
                  <p className="text-xs font-medium" style={{ color }}>{rarity}</p>
                  <p className="text-white text-sm">{discovered}/{count}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <Input
              placeholder="Search fish..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-[#0f3b4f]/60 border-[#52b7d3]/30 text-white placeholder:text-white/40"
            />
          </div>
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <Filter className="w-5 h-5 text-white/40 flex-shrink-0" />
            <button
              onClick={() => setSelectedRarity('all')}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all
                ${selectedRarity === 'all' 
                  ? 'bg-[#52b7d3] text-white' 
                  : 'bg-[#0f3b4f]/60 text-white/60 hover:bg-[#0f3b4f]'
                }
              `}
            >
              All
            </button>
            {rarities.map(rarity => {
              const color = getRarityColor(rarity);
              return (
                <button
                  key={rarity}
                  onClick={() => setSelectedRarity(rarity)}
                  className={`
                    px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all border
                    ${selectedRarity === rarity 
                      ? 'text-white' 
                      : 'text-white/60 hover:text-white border-transparent'
                    }
                  `}
                  style={{ 
                    backgroundColor: selectedRarity === rarity ? color : 'rgba(15, 59, 79, 0.6)',
                    borderColor: selectedRarity === rarity ? color : 'transparent'
                  }}
                >
                  {rarity}
                </button>
              );
            })}
          </div>
        </div>

        {/* Fish Grid */}
        <ScrollArea className="h-[500px]">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredFish.map(fish => {
              const isDiscovered = discoveredFish.has(fish.id);
              const rarityColor = getRarityColor(fish.rarity);
              
              return (
                <div
                  key={fish.id}
                  onClick={() => isDiscovered && setSelectedFish(fish.id)}
                  className={`
                    relative p-4 rounded-xl border-2 transition-all duration-300
                    ${isDiscovered 
                      ? 'bg-[#0f3b4f]/60 cursor-pointer hover:scale-[1.05] hover:shadow-[0_0_20px_rgba(82,183,211,0.3)]' 
                      : 'bg-[#061f2f]/40 opacity-50'
                    }
                  `}
                  style={{ borderColor: isDiscovered ? `${rarityColor}40` : 'transparent' }}
                >
                  {/* Discovered Indicator */}
                  {isDiscovered && (
                    <div className="absolute top-2 right-2">
                      <Check className="w-4 h-4 text-green-400" />
                    </div>
                  )}
                  
                  {/* Fish Icon */}
                  <div 
                    className="w-full aspect-square rounded-xl flex items-center justify-center text-5xl mb-3"
                    style={{ backgroundColor: isDiscovered ? `${rarityColor}15` : 'transparent' }}
                  >
                    {isDiscovered ? '🐟' : <Lock className="w-12 h-12 text-white/20" />}
                  </div>
                  
                  {/* Fish Info */}
                  <div className="text-center">
                    <p className={`font-bold text-sm ${isDiscovered ? 'text-white' : 'text-white/30'}`}>
                      {isDiscovered ? fish.name : '???'}
                    </p>
                    {isDiscovered && (
                      <Badge 
                        className="mt-2 text-xs"
                        style={{ 
                          backgroundColor: `${rarityColor}30`,
                          color: rarityColor
                        }}
                      >
                        {fish.rarity}
                      </Badge>
                    )}
                  </div>
                  
                  {/* Hover Stats */}
                  {isDiscovered && (
                    <div className="absolute inset-0 bg-[#0f3b4f]/95 rounded-xl p-4 opacity-0 hover:opacity-100 transition-opacity flex flex-col justify-center">
                      <p className="text-white font-bold text-center mb-2">{fish.name}</p>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-white/60">Weight:</span>
                          <span className="text-white">{fish.minWeight}-{fish.maxWeight}kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">Value:</span>
                          <span className="text-[#f7d07a]">{fish.baseValue} C$</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/60">XP:</span>
                          <span className="text-green-400">{fish.xp}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
