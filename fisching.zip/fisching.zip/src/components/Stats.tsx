import { useGameState } from '@/hooks/useGameState';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { 
  Fish, 
  TrendingUp, 
  Target, 
  Award, 
  Skull, 
  Clock, 
  MapPin,
  Zap,
  Star,
  Trophy
} from 'lucide-react';

// Stat Card Component
function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  subtext,
  color 
}: { 
  icon: React.ElementType; 
  label: string; 
  value: string | number;
  subtext?: string;
  color: string;
}) {
  return (
    <Card className="bg-[#0f3b4f]/60 border-[#52b7d3]/30 hover:border-[#52b7d3]/60 transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div 
            className="w-12 h-12 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: `${color}20` }}
          >
            <Icon className="w-6 h-6" style={{ color }} />
          </div>
          <div>
            <p className="text-white/60 text-sm">{label}</p>
            <p className="text-white font-bold text-2xl">{value}</p>
            {subtext && <p className="text-white/40 text-xs mt-1">{subtext}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Achievement Card
function AchievementCard({ 
  icon: Icon, 
  name, 
  description, 
  unlocked,
  progress,
  maxProgress
}: { 
  icon: React.ElementType; 
  name: string; 
  description: string;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
}) {
  return (
    <div 
      className={`
        p-4 rounded-xl border-2 transition-all duration-300
        ${unlocked 
          ? 'bg-[#0f3b4f]/60 border-[#f7d07a]/50' 
          : 'bg-[#061f2f]/40 border-white/10 opacity-60'
        }
      `}
    >
      <div className="flex items-start gap-4">
        <div 
          className={`
            w-12 h-12 rounded-xl flex items-center justify-center
            ${unlocked ? 'bg-[#f7d07a]/20' : 'bg-white/5'}
          `}
        >
          <Icon className={`w-6 h-6 ${unlocked ? 'text-[#f7d07a]' : 'text-white/30'}`} />
        </div>
        <div className="flex-1">
          <h3 className={`font-bold ${unlocked ? 'text-white' : 'text-white/40'}`}>{name}</h3>
          <p className="text-white/60 text-sm">{description}</p>
          
          {progress !== undefined && maxProgress !== undefined && !unlocked && (
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-white/40">Progress</span>
                <span className="text-white">{progress} / {maxProgress}</span>
              </div>
              <Progress value={(progress / maxProgress) * 100} className="h-2" />
            </div>
          )}
          
          {unlocked && (
            <div className="mt-2 flex items-center gap-1 text-green-400">
              <Trophy className="w-4 h-4" />
              <span className="text-xs font-medium">Unlocked!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Level Progress Component
function LevelProgress({ level, xp, maxXp }: { level: number; xp: number; maxXp: number }) {
  const progress = (xp / maxXp) * 100;
  
  return (
    <Card className="bg-gradient-to-br from-[#0f3b4f] to-[#061f2f] border-[#52b7d3]/30">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#52b7d3]/30 to-[#1da2c0]/30 flex items-center justify-center">
              <Star className="w-8 h-8 text-[#f7d07a]" />
            </div>
            <div>
              <p className="text-white/60 text-sm">Current Level</p>
              <p className="text-4xl font-bold text-white">{level}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[#f7d07a] font-bold text-xl">{xp.toLocaleString()} / {maxXp.toLocaleString()}</p>
            <p className="text-white/40 text-sm">XP to next level</p>
          </div>
        </div>
        
        <Progress value={progress} className="h-3" />
        
        <div className="mt-4 flex items-center justify-between text-sm">
          <span className="text-white/40">Next unlock at Level {level + 1}</span>
          <span className="text-[#52b7d3]">{Math.round(progress)}%</span>
        </div>
      </CardContent>
    </Card>
  );
}

// Main Stats Component
export function Stats() {
  const { stats, inventory } = useGameState();

  // Calculate additional stats
  const uniqueFishCaught = new Set(inventory.fish.map(f => f.id)).size;
  const totalFishValue = inventory.fish.reduce((sum, f) => sum + f.baseValue, 0);
  // Average fish value (for future use)
  // const averageFishValue = stats.totalFishCaught > 0 
  //   ? Math.floor(totalFishValue / stats.totalFishCaught) 
  //   : 0;

  // Achievements data
  const achievements = [
    {
      icon: Fish,
      name: 'First Catch',
      description: 'Catch your first fish',
      unlocked: stats.totalFishCaught >= 1,
      progress: Math.min(stats.totalFishCaught, 1),
      maxProgress: 1,
    },
    {
      icon: TrendingUp,
      name: 'Streak Master',
      description: 'Achieve a 10 fish catch streak',
      unlocked: stats.bestStreak >= 10,
      progress: stats.bestStreak,
      maxProgress: 10,
    },
    {
      icon: Target,
      name: 'Perfect Angler',
      description: 'Catch 100 fish without snapping your line',
      unlocked: stats.totalFishCaught >= 100,
      progress: stats.totalFishCaught,
      maxProgress: 100,
    },
    {
      icon: Award,
      name: 'Legendary Hunter',
      description: 'Catch a Legendary fish',
      unlocked: inventory.fish.some(f => f.rarity === 'Legendary'),
    },
    {
      icon: Star,
      name: 'Mythical Discovery',
      description: 'Catch a Mythical fish',
      unlocked: inventory.fish.some(f => f.rarity === 'Mythical'),
    },
    {
      icon: Trophy,
      name: 'Master Collector',
      description: 'Discover 50 different fish species',
      unlocked: uniqueFishCaught >= 50,
      progress: uniqueFishCaught,
      maxProgress: 50,
    },
  ];

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Rowdies, sans-serif' }}>
            Statistics
          </h1>
          <p className="text-white/60">Track your fishing journey and achievements</p>
        </div>

        {/* Level Progress */}
        <div className="mb-8">
          <LevelProgress 
            level={stats.level} 
            xp={stats.xp} 
            maxXp={stats.maxXp} 
          />
        </div>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard 
            icon={Fish} 
            label="Total Caught" 
            value={stats.totalFishCaught.toLocaleString()}
            subtext={`${uniqueFishCaught} unique species`}
            color="#52b7d3" 
          />
          <StatCard 
            icon={TrendingUp} 
            label="Current Streak" 
            value={stats.catchStreak}
            subtext={`Best: ${stats.bestStreak}`}
            color="#1da2c0" 
          />
          <StatCard 
            icon={Skull} 
            label="Reels Snapped" 
            value={stats.reelsSnapped}
            subtext="Keep practicing!"
            color="#ef4444" 
          />
          <StatCard 
            icon={Target} 
            label="Success Rate" 
            value={`${stats.totalFishCaught + stats.reelsSnapped > 0 
              ? Math.round((stats.totalFishCaught / (stats.totalFishCaught + stats.reelsSnapped)) * 100) 
              : 0}%`}
            subtext="Catch vs Snap ratio"
            color="#f7d07a" 
          />
        </div>

        {/* Secondary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-[#0f3b4f]/60 border-[#52b7d3]/30">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Zap className="w-6 h-6 text-[#f7d07a]" />
                <div>
                  <p className="text-white/60 text-sm">Total XP Earned</p>
                  <p className="text-white font-bold text-xl">
                    {((stats.level - 1) * 100 + stats.xp).toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f3b4f]/60 border-[#52b7d3]/30">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <MapPin className="w-6 h-6 text-[#52b7d3]" />
                <div>
                  <p className="text-white/60 text-sm">Locations Visited</p>
                  <p className="text-white font-bold text-xl">1 / 5</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f3b4f]/60 border-[#52b7d3]/30">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-green-400" />
                <div>
                  <p className="text-white/60 text-sm">Time Played</p>
                  <p className="text-white font-bold text-xl">Just Started</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Achievements */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-[#f7d07a]" />
            Achievements
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement, index) => (
              <AchievementCard key={index} {...achievement} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
