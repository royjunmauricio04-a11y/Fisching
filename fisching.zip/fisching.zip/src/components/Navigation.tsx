import { useState } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { Waves, Backpack, BookOpen, Store, BarChart3 } from 'lucide-react';

type Tab = 'dashboard' | 'inventory' | 'bestiary' | 'shop' | 'stats';

interface NavigationProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const { stats } = useGameState();
  const [isHovered, setIsHovered] = useState(false);

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Waves },
    { id: 'inventory', label: 'Inventory', icon: Backpack },
    { id: 'bestiary', label: 'Bestiary', icon: BookOpen },
    { id: 'shop', label: 'Shop', icon: Store },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
  ];

  return (
    <nav 
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div 
        className={`
          flex items-center gap-2 px-4 py-3 rounded-2xl
          backdrop-blur-xl bg-[#0f3b4f]/80 border border-[#52b7d3]/30
          shadow-[0_8px_32px_rgba(82,183,211,0.2)]
          transition-all duration-500 ease-out
          ${isHovered ? 'scale-105' : 'scale-100'}
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-2 pr-4 border-r border-[#52b7d3]/30">
          <Waves className="w-6 h-6 text-[#52b7d3]" />
          <span className="font-bold text-lg text-white tracking-wider" style={{ fontFamily: 'Rowdies, sans-serif' }}>
            FISCH
          </span>
        </div>

        {/* Navigation Links */}
        <div className="flex items-center gap-1 pl-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  relative flex items-center gap-2 px-4 py-2 rounded-xl
                  transition-all duration-300 ease-out
                  ${isActive 
                    ? 'bg-[#52b7d3]/20 text-[#52b7d3]' 
                    : 'text-white/70 hover:text-white hover:bg-white/5'
                  }
                `}
              >
                <Icon className={`w-4 h-4 transition-transform duration-300 ${isActive ? 'scale-110' : ''}`} />
                <span className="text-sm font-medium">{tab.label}</span>
                
                {/* Active Indicator */}
                {isActive && (
                  <div className="absolute inset-0 rounded-xl bg-[#52b7d3]/10 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Currency */}
        <div className="flex items-center gap-2 pl-4 border-l border-[#52b7d3]/30">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#f7d07a] to-[#d4a84b] flex items-center justify-center">
            <span className="text-xs font-bold text-[#061f2f]">C</span>
          </div>
          <span className="text-[#f7d07a] font-bold tabular-nums">
            {stats.money.toLocaleString()}
          </span>
        </div>
      </div>
    </nav>
  );
}
