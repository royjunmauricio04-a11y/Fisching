import { useState } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
// Badge import removed - not used
import { ScrollArea } from '@/components/ui/scroll-area';
import { ShoppingCart, Worm, Anchor, Package, Check, Lock, Sparkles } from 'lucide-react';
import { rodDatabase } from '@/data/rodDatabase';
import { baitDatabase } from '@/data/baitDatabase';

// Rod Shop Card
function RodShopCard({ 
  rod, 
  canAfford, 
  canUnlock, 
  onBuy 
}: { 
  rod: typeof rodDatabase[0]; 
  canAfford: boolean;
  canUnlock: boolean;
  onBuy: () => void;
}) {
  return (
    <div 
      className={`
        relative p-5 rounded-xl border-2 transition-all duration-300
        ${rod.owned 
          ? 'bg-green-500/10 border-green-500/50' 
          : canAfford && canUnlock
            ? 'bg-[#0f3b4f]/60 border-[#52b7d3]/30 hover:border-[#52b7d3] hover:shadow-[0_0_20px_rgba(82,183,211,0.2)]'
            : 'bg-[#061f2f]/40 border-white/10 opacity-60'
        }
      `}
    >
      {rod.owned && (
        <div className="absolute top-3 right-3 flex items-center gap-1 text-green-400">
          <Check className="w-4 h-4" />
          <span className="text-xs font-medium">Owned</span>
        </div>
      )}
      
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#52b7d3]/20 to-[#1da2c0]/20 flex items-center justify-center text-3xl">
          🎣
        </div>
        
        <div className="flex-1">
          <h3 className="font-bold text-white text-lg">{rod.name}</h3>
          <p className="text-white/60 text-sm">{rod.description}</p>
          
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-3">
            <div className="text-xs">
              <span className="text-white/40">Luck:</span>
              <span className="text-[#f7d07a] ml-1">+{rod.luck}%</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Speed:</span>
              <span className="text-[#52b7d3] ml-1">+{rod.lureSpeed}%</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Resilience:</span>
              <span className="text-green-400 ml-1">+{rod.resilience}%</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Control:</span>
              <span className="text-purple-400 ml-1">+{rod.control}%</span>
            </div>
          </div>
          
          {rod.passive && (
            <div className="mt-3 flex items-center gap-2">
              <Sparkles className="w-3 h-3 text-[#f7d07a]" />
              <p className="text-xs text-[#f7d07a] italic">{rod.passive}</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
        <div>
          <p className="text-white/40 text-xs">Required Level</p>
          <p className={canUnlock ? 'text-white' : 'text-red-400'}>Level {rod.levelRequired}</p>
        </div>
        
        {!rod.owned && (
          <Button
            onClick={onBuy}
            disabled={!canAfford || !canUnlock}
            className={`
              ${canAfford && canUnlock
                ? 'bg-gradient-to-r from-[#f7d07a] to-[#d4a84b] text-[#061f2f] hover:opacity-90'
                : 'bg-white/10 text-white/40 cursor-not-allowed'
              }
            `}
          >
            {canAfford && canUnlock ? (
              <>
                <ShoppingCart className="w-4 h-4 mr-2" />
                {rod.cost.toLocaleString()} C$
              </>
            ) : !canUnlock ? (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Locked
              </>
            ) : (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Need {rod.cost.toLocaleString()} C$
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

// Bait Shop Card
function BaitShopCard({ 
  bait, 
  canAfford, 
  onBuy 
}: { 
  bait: typeof baitDatabase[0]; 
  canAfford: boolean;
  onBuy: (amount: number) => void;
}) {
  const [amount, setAmount] = useState(1);
  const totalCost = bait.cost * amount;
  // Check if can afford amount (for future use)
  // const canAffordAmount = canAfford && totalCost <= bait.cost;

  return (
    <div className="p-5 rounded-xl bg-[#0f3b4f]/60 border border-[#52b7d3]/30 hover:border-[#52b7d3]/60 transition-all duration-300">
      <div className="flex items-start gap-4">
        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#f7d07a]/20 to-[#d4a84b]/20 flex items-center justify-center text-2xl">
          🪱
        </div>
        
        <div className="flex-1">
          <h3 className="font-bold text-white">{bait.name}</h3>
          <p className="text-white/60 text-sm">{bait.description}</p>
          
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="text-xs">
              <span className="text-white/40">Luck:</span>
              <span className="text-[#f7d07a] ml-1">+{bait.luck}%</span>
            </div>
            <div className="text-xs">
              <span className="text-white/40">Speed:</span>
              <span className="text-[#52b7d3] ml-1">+{bait.lureSpeed}%</span>
            </div>
            {bait.preferredLuck > 0 && (
              <div className="text-xs col-span-2">
                <span className="text-white/40">Preferred Fish:</span>
                <span className="text-green-400 ml-1">+{bait.preferredLuck}%</span>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAmount(Math.max(1, amount - 1))}
              className="w-8 h-8 rounded-lg bg-[#061f2f] text-white hover:bg-[#0f3b4f] transition-colors"
            >
              -
            </button>
            <span className="text-white font-bold w-8 text-center">{amount}</span>
            <button
              onClick={() => setAmount(amount + 1)}
              className="w-8 h-8 rounded-lg bg-[#061f2f] text-white hover:bg-[#0f3b4f] transition-colors"
            >
              +
            </button>
          </div>
          <p className="text-[#f7d07a] font-bold">{totalCost} C$</p>
        </div>
        
        <Button
          onClick={() => onBuy(amount)}
          disabled={!canAfford}
          className={`
            w-full ${canAfford
              ? 'bg-gradient-to-r from-[#52b7d3] to-[#1da2c0] text-white hover:opacity-90'
              : 'bg-white/10 text-white/40 cursor-not-allowed'
            }
          `}
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Buy {amount}
        </Button>
      </div>
    </div>
  );
}

// Main Shop Component
export function Shop() {
  const { stats, inventory, buyRod, buyBait } = useGameState();
  const [activeTab, setActiveTab] = useState('rods');

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Rowdies, sans-serif' }}>
              Shop
            </h1>
            <p className="text-white/60">Upgrade your gear and stock up on supplies</p>
          </div>
          
          {/* Currency Display */}
          <div className="flex items-center gap-3 bg-[#0f3b4f]/60 px-6 py-3 rounded-xl border border-[#f7d07a]/30">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#f7d07a] to-[#d4a84b] flex items-center justify-center">
              <span className="text-lg font-bold text-[#061f2f]">C</span>
            </div>
            <div>
              <p className="text-white/40 text-xs">Your Balance</p>
              <p className="text-[#f7d07a] font-bold text-xl">{stats.money.toLocaleString()} C$</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-[#0f3b4f]/60 p-1 rounded-xl">
            <TabsTrigger 
              value="rods" 
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Anchor className="w-4 h-4 mr-2" />
              Fishing Rods
            </TabsTrigger>
            <TabsTrigger 
              value="bait"
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Worm className="w-4 h-4 mr-2" />
              Bait & Tackle
            </TabsTrigger>
            <TabsTrigger 
              value="crates"
              className="data-[state=active]:bg-[#52b7d3] data-[state=active]:text-white rounded-lg px-6"
            >
              <Package className="w-4 h-4 mr-2" />
              Crates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rods" className="space-y-4">
            <ScrollArea className="h-[600px]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {inventory.rods.map(rod => (
                  <RodShopCard
                    key={rod.id}
                    rod={rod}
                    canAfford={stats.money >= rod.cost}
                    canUnlock={stats.level >= rod.levelRequired}
                    onBuy={() => buyRod(rod.id)}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="bait" className="space-y-4">
            <ScrollArea className="h-[600px]">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {inventory.bait.map(bait => (
                  <BaitShopCard
                    key={bait.id}
                    bait={bait}
                    canAfford={stats.money >= bait.cost}
                    onBuy={(amount) => buyBait(bait.id, amount)}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="crates" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Bait Crate */}
              <div className="p-6 rounded-xl bg-[#0f3b4f]/60 border border-[#52b7d3]/30">
                <div className="w-20 h-20 mx-auto rounded-xl bg-gradient-to-br from-[#8B4513]/40 to-[#D2691E]/40 flex items-center justify-center text-4xl mb-4">
                  📦
                </div>
                <h3 className="text-xl font-bold text-white text-center">Bait Crate</h3>
                <p className="text-white/60 text-center text-sm mt-2">Contains 4-6 random bait pieces</p>
                <div className="mt-4 text-center">
                  <p className="text-[#f7d07a] font-bold text-2xl">50 C$</p>
                </div>
                <Button className="w-full mt-4 bg-gradient-to-r from-[#52b7d3] to-[#1da2c0] text-white">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy Crate
                </Button>
              </div>

              {/* Enchant Relic */}
              <div className="p-6 rounded-xl bg-[#0f3b4f]/60 border border-purple-500/30">
                <div className="w-20 h-20 mx-auto rounded-xl bg-gradient-to-br from-purple-500/40 to-pink-500/40 flex items-center justify-center text-4xl mb-4">
                  🔮
                </div>
                <h3 className="text-xl font-bold text-white text-center">Enchant Relic</h3>
                <p className="text-white/60 text-center text-sm mt-2">Enchant your rod with special powers</p>
                <div className="mt-4 text-center">
                  <p className="text-[#f7d07a] font-bold text-2xl">11,000 C$</p>
                </div>
                <Button className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy Relic
                </Button>
              </div>

              {/* Exalted Relic */}
              <div className="p-6 rounded-xl bg-[#0f3b4f]/60 border border-yellow-500/30">
                <div className="w-20 h-20 mx-auto rounded-xl bg-gradient-to-br from-yellow-500/40 to-orange-500/40 flex items-center justify-center text-4xl mb-4">
                  ⭐
                </div>
                <h3 className="text-xl font-bold text-white text-center">Exalted Relic</h3>
                <p className="text-white/60 text-center text-sm mt-2">Powerful enchantments for end-game rods</p>
                <div className="mt-4 text-center">
                  <p className="text-[#f7d07a] font-bold text-2xl">Rare Drop</p>
                </div>
                <Button 
                  disabled
                  className="w-full mt-4 bg-white/10 text-white/40 cursor-not-allowed"
                >
                  <Lock className="w-4 h-4 mr-2" />
                  Fish to Find
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
