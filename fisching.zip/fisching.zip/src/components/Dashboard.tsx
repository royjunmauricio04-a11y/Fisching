import { useState, useEffect, useRef, useCallback } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { Fish, Zap, Target, TrendingUp, MapPin, Award } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { fishDatabase } from '@/data/fishDatabase';

// Fishing Minigame Component
function FishingMinigame() {
  const { 
    gamePhase, 
    activeFish, 
    equippedRod,
    castLine, 
    shakeLine, 
    updateReelProgress 
  } = useGameState();
  
  const [castPower, setCastPower] = useState(0);
  const [castDirection, setCastDirection] = useState(1);
  // Shake state (for future implementation)
  // const [shakePosition, setShakePosition] = useState({ x: 50, y: 50 });
  // const [shakeClicks, setShakeClicks] = useState(0);
  
  // Reeling game state
  const [fishPosition, setFishPosition] = useState(50);
  const [barPosition, setBarPosition] = useState(50);
  const [progress, setProgress] = useState(50);
  const [isHolding, setIsHolding] = useState(false);
  // Fish direction state (for future implementation)
  // const [fishDirection, setFishDirection] = useState(1);
  
  const reelingRef = useRef<number | null>(null);
  const fishMovementRef = useRef<number | null>(null);

  // Casting minigame
  useEffect(() => {
    if (gamePhase !== 'casting') return;
    
    const interval = setInterval(() => {
      setCastPower(prev => {
        const next = prev + castDirection * 2;
        if (next >= 100 || next <= 0) {
          setCastDirection(d => -d);
        }
        return Math.max(0, Math.min(100, next));
      });
    }, 20);
    
    return () => clearInterval(interval);
  }, [gamePhase, castDirection]);

  // Handle cast click
  const handleCastClick = () => {
    if (gamePhase === 'casting') {
      castLine();
    }
  };

  // Shaking minigame
  useEffect(() => {
    if (gamePhase !== 'shaking') return;
    
    // Auto-trigger shake after short delay for simplicity
    const timeout = setTimeout(() => {
      shakeLine();
    }, 1500);
    
    return () => clearTimeout(timeout);
  }, [gamePhase, shakeLine]);

  // Reeling minigame
  useEffect(() => {
    if (gamePhase !== 'reeling' || !activeFish) return;
    
    // Fish movement
    fishMovementRef.current = window.setInterval(() => {
      setFishPosition(prev => {
        const resilience = activeFish.resilience;
        const change = (Math.random() - 0.5) * (resilience / 10);
        return Math.max(10, Math.min(90, prev + change));
      });
    }, 100);
    
    // Game loop
    reelingRef.current = window.setInterval(() => {
      setBarPosition(prev => {
        const control = (equippedRod?.control || 0) / 100;
        const barWidth = 30 + control * 40; // 30% to 70%
        
        let next = prev;
        if (isHolding) {
          next = prev + 3;
        } else {
          next = prev - 2;
        }
        next = Math.max(barWidth / 2, Math.min(100 - barWidth / 2, next));
        return next;
      });
      
      setProgress(prev => {
        const barWidth = 30 + (equippedRod?.control || 0) / 100 * 40;
        const fishInBar = Math.abs(fishPosition - barPosition) < barWidth / 2;
        
        let change = fishInBar ? 1.5 : -1;
        change *= (1 + (activeFish.progressSpeed || 12) / 20);
        
        const next = Math.max(0, Math.min(100, prev + change));
        updateReelProgress(next);
        return next;
      });
    }, 50);
    
    return () => {
      if (fishMovementRef.current) clearInterval(fishMovementRef.current);
      if (reelingRef.current) clearInterval(reelingRef.current);
    };
  }, [gamePhase, activeFish, isHolding, fishPosition, barPosition, equippedRod, updateReelProgress]);

  // Render based on game phase
  if (gamePhase === 'idle') {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Ready to Fish?</h2>
          <p className="text-white/60">Click the button below to cast your line</p>
        </div>
        <Button
          onClick={castLine}
          className="px-12 py-6 text-xl font-bold bg-gradient-to-r from-[#52b7d3] to-[#1da2c0] hover:from-[#1da2c0] hover:to-[#52b7d3] text-white rounded-2xl shadow-[0_0_30px_rgba(82,183,211,0.5)] transition-all duration-300 hover:scale-105"
        >
          CAST LINE
        </Button>
      </div>
    );
  }

  if (gamePhase === 'casting') {
    const getCastRating = () => {
      if (castPower >= 95) return { text: 'PERFECT!!', color: '#00ff00' };
      if (castPower >= 85) return { text: 'Amazing!', color: '#7fff00' };
      if (castPower >= 70) return { text: 'Great!', color: '#ffff00' };
      if (castPower >= 50) return { text: 'Good!', color: '#ffaa00' };
      if (castPower >= 30) return { text: 'Fine.', color: '#ff8800' };
      return { text: 'Meh..', color: '#ff6600' };
    };
    
    const rating = getCastRating();
    
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-2xl font-bold text-white mb-8">Click to Cast!</h2>
        <div className="w-64 h-8 bg-[#061f2f] rounded-full overflow-hidden border-2 border-[#52b7d3]/50 relative">
          <div 
            className="h-full bg-gradient-to-r from-[#52b7d3] via-[#7dd3ed] to-[#52b7d3] transition-all duration-75"
            style={{ width: `${castPower}%` }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-sm font-bold text-white drop-shadow-md">{rating.text}</span>
          </div>
          {/* Perfect zone */}
          <div className="absolute right-0 top-0 w-[5%] h-full bg-green-500/30 border-l-2 border-green-500" />
        </div>
        <Button
          onClick={handleCastClick}
          className="mt-8 px-8 py-4 bg-[#52b7d3] hover:bg-[#1da2c0] text-white font-bold rounded-xl"
        >
          CAST NOW
        </Button>
      </div>
    );
  }

  if (gamePhase === 'shaking') {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="animate-bounce mb-4">
          <span className="text-4xl">🎣</span>
        </div>
        <h2 className="text-2xl font-bold text-white mb-4">Wait for a bite...</h2>
        <div className="w-48 h-2 bg-[#061f2f] rounded-full overflow-hidden">
          <div className="h-full bg-[#52b7d3] animate-pulse" style={{ width: '60%' }} />
        </div>
      </div>
    );
  }

  if (gamePhase === 'reeling' && activeFish) {
    const barWidth = 30 + (equippedRod?.control || 0) / 100 * 40;
    
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-center mb-4">
          <span className="text-4xl">🐟</span>
          <h3 className="text-xl font-bold text-white mt-2">Something bit!</h3>
          <p className="text-[#52b7d3]">Keep the fish in the white bar!</p>
        </div>
        
        {/* Reeling Bar */}
        <div 
          className="relative w-80 h-16 bg-[#061f2f] rounded-xl border-2 border-[#52b7d3]/50 overflow-hidden"
          onMouseDown={() => setIsHolding(true)}
          onMouseUp={() => setIsHolding(false)}
          onMouseLeave={() => setIsHolding(false)}
          onTouchStart={() => setIsHolding(true)}
          onTouchEnd={() => setIsHolding(false)}
        >
          {/* Progress fill */}
          <div 
            className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-[#52b7d3] to-[#7dd3ed] transition-all duration-100"
            style={{ width: `${progress}%` }}
          />
          
          {/* Control Bar */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 h-12 bg-white/90 rounded-lg shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-75"
            style={{ 
              left: `${barPosition - barWidth / 2}%`,
              width: `${barWidth}%`
            }}
          />
          
          {/* Fish */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 w-8 h-8 bg-gradient-to-br from-red-500 to-orange-500 rounded-full shadow-[0_0_15px_rgba(255,0,0,0.5)] transition-all duration-100 flex items-center justify-center"
            style={{ left: `${fishPosition}%`, transform: `translate(-50%, -50%)` }}
          >
            <span className="text-lg">🐟</span>
          </div>
        </div>
        
        <p className="text-white/60 text-sm mt-4">
          {isHolding ? 'Reeling...' : 'Hold to reel!'}
        </p>
        
        {/* Progress Bar */}
        <div className="w-80 mt-4">
          <Progress value={progress} className="h-3" />
        </div>
      </div>
    );
  }

  if (gamePhase === 'caught' && activeFish) {
    const value = Math.floor(activeFish.fish.baseValue * (activeFish.weight / activeFish.fish.minWeight));
    
    return (
      <div className="flex flex-col items-center justify-center h-full animate-in zoom-in duration-300">
        <div className="text-6xl mb-4">🎉</div>
        <h2 className="text-3xl font-bold text-[#f7d07a] mb-2">CAUGHT!</h2>
        <div className="text-center">
          <p className="text-2xl font-bold text-white">{activeFish.fish.name}</p>
          <p className="text-[#52b7d3]">{activeFish.weight.toFixed(2)} kg</p>
          <p className="text-[#f7d07a] font-bold mt-2">+{value} C$</p>
          <p className="text-green-400">+{activeFish.fish.xp} XP</p>
        </div>
      </div>
    );
  }

  if (gamePhase === 'escaped') {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-6xl mb-4">😢</div>
        <h2 className="text-2xl font-bold text-red-400">It got away!</h2>
        <p className="text-white/60 mt-2">Better luck next time...</p>
      </div>
    );
  }

  return null;
}

// Stats Card Component
function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  color 
}: { 
  icon: React.ElementType; 
  label: string; 
  value: string | number; 
  color: string;
}) {
  return (
    <div className="bg-[#0f3b4f]/60 backdrop-blur-sm rounded-xl p-4 border border-[#52b7d3]/20 hover:border-[#52b7d3]/50 transition-all duration-300">
      <div className="flex items-center gap-3">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${color}20` }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-white/60 text-xs">{label}</p>
          <p className="text-white font-bold text-lg">{value}</p>
        </div>
      </div>
    </div>
  );
}

// Main Dashboard Component
export function Dashboard() {
  const { stats, equippedRod, equippedBait, currentLocation, inventory } = useGameState();
  
  const discoveredCount = fishDatabase.filter(f => 
    inventory.fish.some(caught => caught.id === f.id)
  ).length;

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Rowdies, sans-serif' }}>
            Dashboard
          </h1>
          <p className="text-white/60">Welcome back, {stats.title}!</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Fishing Area */}
          <div className="lg:col-span-2">
            <div className="bg-gradient-to-br from-[#0f3b4f] to-[#061f2f] rounded-3xl p-8 border border-[#52b7d3]/30 shadow-[0_0_40px_rgba(82,183,211,0.15)] h-[500px]">
              <FishingMinigame />
            </div>
          </div>

          {/* Stats Panel */}
          <div className="space-y-4">
            {/* Level Card */}
            <div className="bg-gradient-to-br from-[#0f3b4f] to-[#061f2f] rounded-2xl p-6 border border-[#52b7d3]/30">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-white/60 text-sm">Level {stats.level}</p>
                  <p className="text-[#f7d07a] font-bold text-xl">{stats.title}</p>
                </div>
                <Award className="w-10 h-10 text-[#f7d07a]" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-white/60">XP</span>
                  <span className="text-white">{stats.xp.toLocaleString()} / {stats.maxXp.toLocaleString()}</span>
                </div>
                <Progress value={(stats.xp / stats.maxXp) * 100} className="h-2" />
              </div>
            </div>

            {/* Quick Stats */}
            <StatCard 
              icon={Fish} 
              label="Fish Caught" 
              value={stats.totalFishCaught} 
              color="#52b7d3" 
            />
            <StatCard 
              icon={TrendingUp} 
              label="Catch Streak" 
              value={stats.catchStreak} 
              color="#1da2c0" 
            />
            <StatCard 
              icon={Target} 
              label="Best Streak" 
              value={stats.bestStreak} 
              color="#f7d07a" 
            />
            <StatCard 
              icon={BookOpen} 
              label="Discovered" 
              value={`${discoveredCount}/${fishDatabase.length}`} 
              color="#7dd3ed" 
            />

            {/* Equipment */}
            <div className="bg-[#0f3b4f]/60 backdrop-blur-sm rounded-xl p-4 border border-[#52b7d3]/20">
              <p className="text-white/60 text-xs mb-3">EQUIPMENT</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#52b7d3]/20 flex items-center justify-center">
                    <span className="text-lg">🎣</span>
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">{equippedRod?.name || 'No Rod'}</p>
                    <p className="text-white/40 text-xs">+{equippedRod?.luck || 0}% Luck</p>
                  </div>
                </div>
                {equippedBait && (
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#f7d07a]/20 flex items-center justify-center">
                      <span className="text-lg">🪱</span>
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{equippedBait.name}</p>
                      <p className="text-white/40 text-xs">{equippedBait.count} remaining</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Location */}
            <div className="bg-[#0f3b4f]/60 backdrop-blur-sm rounded-xl p-4 border border-[#52b7d3]/20">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#52b7d3]" />
                <div>
                  <p className="text-white/60 text-xs">Current Location</p>
                  <p className="text-white font-medium">{currentLocation?.name || 'Unknown'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}