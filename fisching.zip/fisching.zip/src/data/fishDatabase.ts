import type { Fish, Mutation, Rarity } from '@/types/game';

const mutations: Mutation[] = [
  { type: 'Normal', valueMultiplier: 1, chance: 70 },
  { type: 'Shiny', valueMultiplier: 1.5, chance: 15 },
  { type: 'Gilded', valueMultiplier: 2, chance: 8 },
  { type: 'Crystal', valueMultiplier: 3, chance: 4 },
  { type: 'Abyssal', valueMultiplier: 5, chance: 2 },
  { type: 'Celestial', valueMultiplier: 10, chance: 1 },
];

const createFish = (
  id: string,
  name: string,
  rarity: Rarity,
  baseValue: number,
  minWeight: number,
  maxWeight: number,
  xp: number,
  location: string[],
  description: string,
  options?: { weather?: string[]; time?: string[]; bait?: string[] }
): Fish => ({
  id,
  name,
  rarity,
  baseValue,
  minWeight,
  maxWeight,
  xp,
  location,
  description,
  weather: options?.weather,
  time: options?.time,
  bait: options?.bait,
  unlocked: false,
  caughtCount: 0,
  bestWeight: 0,
  mutations,
});

export const fishDatabase: Fish[] = [
  // Trash
  createFish('trash_boot', 'Old Boot', 'Trash', 5, 0.5, 2, 5, ['any'], 'Just an old, soggy boot.'),
  createFish('trash_can', 'Rusty Can', 'Trash', 3, 0.1, 0.5, 3, ['any'], 'A discarded tin can.'),
  createFish('trash_seaweed', 'Seaweed Clump', 'Trash', 2, 0.2, 1, 2, ['any'], 'Just some seaweed.'),
  
  // Common
  createFish('common_anchovy', 'Anchovy', 'Common', 15, 0.1, 0.3, 10, ['Moosewood', 'Roslit Bay'], 'A small, common fish.'),
  createFish('common_sardine', 'Sardine', 'Common', 18, 0.2, 0.5, 12, ['Moosewood', 'Roslit Bay'], 'Often found in large schools.'),
  createFish('common_herring', 'Herring', 'Common', 20, 0.3, 0.8, 15, ['Moosewood'], 'Silvery and quick.'),
  createFish('common_mackerel', 'Mackerel', 'Common', 25, 0.5, 1.5, 18, ['Moosewood', 'Roslit Bay'], 'Striped and fast.'),
  createFish('common_cod', 'Cod', 'Common', 30, 1, 5, 20, ['Moosewood', 'Forsaken Shores'], 'A popular food fish.'),
  
  // Uncommon
  createFish('uncommon_trout', 'Trout', 'Uncommon', 45, 0.5, 3, 25, ['Moosewood', 'Roslit Bay'], 'Freshwater favorite.'),
  createFish('uncommon_bass', 'Bass', 'Uncommon', 50, 1, 4, 28, ['Moosewood', 'Roslit Bay'], 'A sporty catch.'),
  createFish('uncommon_perch', 'Perch', 'Uncommon', 40, 0.3, 1.5, 22, ['Roslit Bay'], 'Colorful and tasty.'),
  createFish('uncommon_wrasse', 'Wrasse', 'Uncommon', 55, 0.5, 2, 30, ['Roslit Bay'], 'Vibrant reef dweller.'),
  
  // Unusual
  createFish('unusual_pike', 'Pike', 'Unusual', 80, 2, 8, 40, ['Moosewood'], 'A fierce predator.'),
  createFish('unusual_carp', 'Carp', 'Unusual', 70, 3, 15, 38, ['Moosewood'], 'Can grow very large.'),
  createFish('unusual_catfish', 'Catfish', 'Unusual', 85, 2, 10, 42, ['Forsaken Shores'], 'Bottom feeder with whiskers.'),
  createFish('unusual_snapper', 'Red Snapper', 'Unusual', 90, 1, 5, 45, ['Roslit Bay'], 'Delicious and vibrant.'),
  
  // Rare
  createFish('rare_tuna', 'Bluefin Tuna', 'Rare', 200, 50, 200, 80, ['Forsaken Shores'], 'A massive, powerful fish.'),
  createFish('rare_swordfish', 'Swordfish', 'Rare', 250, 30, 150, 90, ['Forsaken Shores'], 'Has a long, pointed bill.'),
  createFish('rare_marlin', 'Marlin', 'Rare', 300, 40, 180, 100, ['Forsaken Shores'], 'Incredibly fast swimmer.'),
  createFish('rare_mahi', 'Mahi-Mahi', 'Rare', 180, 5, 20, 75, ['Roslit Bay'], 'Colorful and acrobatic.'),
  createFish('rare_stingray', 'Stingray', 'Rare', 220, 10, 50, 85, ['Roslit Bay'], 'Glides along the bottom.'),
  
  // Legendary
  createFish('legendary_shark', 'Great White Shark', 'Legendary', 800, 500, 2000, 200, ['Forsaken Shores'], 'The ocean\'s apex predator.'),
  createFish('legendary_sunfish', 'Ocean Sunfish', 'Legendary', 600, 100, 500, 180, ['Roslit Bay'], 'Strange and massive.'),
  createFish('legendary_angler', 'Anglerfish', 'Legendary', 750, 2, 10, 190, ['The Depths'], 'Has a glowing lure.'),
  createFish('legendary_oarfish', 'Oarfish', 'Legendary', 900, 50, 300, 220, ['The Depths'], 'Long and serpentine.'),
  
  // Mythical
  createFish('mythical_kraken', 'Kraken', 'Mythical', 3000, 1000, 5000, 500, ['The Depths'], 'A legendary sea monster.'),
  createFish('mythical_leviathan', 'Leviathan', 'Mythical', 4000, 2000, 8000, 600, ['Abyssal Zenith'], 'Ancient and colossal.'),
  createFish('mythical_colossal', 'Colossal Squid', 'Mythical', 3500, 800, 3000, 550, ['The Depths'], 'Lives in the deep.'),
  
  // Exotic
  createFish('exotic_coelacanth', 'Coelacanth', 'Exotic', 5000, 50, 150, 800, ['Ancient Isle'], 'A living fossil.'),
  createFish('exotic_megalodon', 'Megalodon', 'Exotic', 8000, 5000, 20000, 1000, ['Ancient Isle'], 'Prehistoric giant shark.'),
  
  // Secret
  createFish('secret_nessie', 'Nessie', 'Secret', 50000, 10000, 50000, 5000, ['Mystery Lake'], 'The legendary lake monster.'),
  createFish('secret_mermaid', 'Mermaid', 'Secret', 100000, 40, 70, 10000, ['Coral Kingdom'], 'A mythical sea creature.'),
];

export const getRarityColor = (rarity: Rarity): string => {
  const colors: Record<Rarity, string> = {
    'Trash': '#8B8B8B',
    'Common': '#FFFFFF',
    'Uncommon': '#1EFF00',
    'Unusual': '#0070DD',
    'Rare': '#A335EE',
    'Legendary': '#FF8000',
    'Mythical': '#E6CC80',
    'Exotic': '#00FFFF',
    'Secret': '#FF0066',
    'Relic': '#FFD700',
    'Fragment': '#C0C0C0',
    'Extinct': '#8B4513',
    'Limited': '#FF1493',
    'Apex': '#DC143C',
    'Cataclysmic': '#9400D3',
    'Special': '#00FF7F',
  };
  return colors[rarity] || '#FFFFFF';
};

export const getRarityChance = (rarity: Rarity): number => {
  const chances: Record<Rarity, number> = {
    'Trash': 15,
    'Common': 40,
    'Uncommon': 20,
    'Unusual': 12,
    'Rare': 8,
    'Legendary': 3,
    'Mythical': 1.5,
    'Exotic': 0.5,
    'Secret': 0.05,
    'Relic': 0.1,
    'Fragment': 0.2,
    'Extinct': 0.3,
    'Limited': 0.4,
    'Apex': 0.08,
    'Cataclysmic': 0.02,
    'Special': 0.6,
  };
  return chances[rarity] || 0;
};
