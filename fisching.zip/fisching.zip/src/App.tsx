import { useState, useEffect } from 'react';
import { GameStateProvider } from '@/hooks/useGameState';
import { Navigation } from '@/components/Navigation';
import { Dashboard } from '@/components/Dashboard';
import { Inventory } from '@/components/Inventory';
import { Bestiary } from '@/components/Bestiary';
import { Shop } from '@/components/Shop';
import { Stats } from '@/components/Stats';
import './App.css';

type Tab = 'dashboard' | 'inventory' | 'bestiary' | 'shop' | 'stats';

// Bubble Background Component
function BubbleBackground() {
  const [bubbles, setBubbles] = useState<Array<{ id: number; x: number; size: number; duration: number; delay: number }>>([]);

  useEffect(() => {
    const newBubbles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: Math.random() * 20 + 5,
      duration: Math.random() * 10 + 10,
      delay: Math.random() * 10,
    }));
    setBubbles(newBubbles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {bubbles.map(bubble => (
        <div
          key={bubble.id}
          className="absolute rounded-full bg-[#52b7d3]/10 animate-bubble-rise"
          style={{
            left: `${bubble.x}%`,
            bottom: '-50px',
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            animationDuration: `${bubble.duration}s`,
            animationDelay: `${bubble.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

// Light Rays Component
function LightRays() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      <div 
        className="absolute top-0 left-1/4 w-32 h-full opacity-10"
        style={{
          background: 'linear-gradient(180deg, rgba(82, 183, 211, 0.5) 0%, transparent 80%)',
          transform: 'rotate(-15deg)',
          transformOrigin: 'top center',
        }}
      />
      <div 
        className="absolute top-0 left-1/2 w-24 h-full opacity-10"
        style={{
          background: 'linear-gradient(180deg, rgba(82, 183, 211, 0.5) 0%, transparent 80%)',
          transform: 'rotate(5deg)',
          transformOrigin: 'top center',
        }}
      />
      <div 
        className="absolute top-0 right-1/3 w-40 h-full opacity-10"
        style={{
          background: 'linear-gradient(180deg, rgba(82, 183, 211, 0.5) 0%, transparent 80%)',
          transform: 'rotate(20deg)',
          transformOrigin: 'top center',
        }}
      />
    </div>
  );
}

// Main App Content
function AppContent() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#061f2f] via-[#0a2d3d] to-[#061f2f] relative">
      {/* Background Effects */}
      <BubbleBackground />
      <LightRays />
      
      {/* Caustic Pattern Overlay */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M50 0 Q60 25 50 50 Q40 75 50 100' stroke='%2352b7d3' fill='none' stroke-width='0.5'/%3E%3Cpath d='M0 50 Q25 40 50 50 Q75 60 100 50' stroke='%2352b7d3' fill='none' stroke-width='0.5'/%3E%3C/svg%3E")`,
          backgroundSize: '100px 100px',
        }}
      />
      
      {/* Navigation */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      {/* Main Content */}
      <main className="relative z-10">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'inventory' && <Inventory />}
        {activeTab === 'bestiary' && <Bestiary />}
        {activeTab === 'shop' && <Shop />}
        {activeTab === 'stats' && <Stats />}
      </main>
    </div>
  );
}

// Main App
function App() {
  return (
    <GameStateProvider>
      <AppContent />
    </GameStateProvider>
  );
}

export default App;
